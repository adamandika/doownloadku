<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'wordpress' );

/** MySQL database username */
define( 'DB_USER', 'adamandika' );

/** MySQL database password */
define( 'DB_PASSWORD', '1234567890' );

/** MySQL hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         '@u|+N#Jy/KgV!#X6*!*jDqK2U;5Dk1uLrPRN+H8@~S=KJ}5t&v/0*s++?dHW0$H[' );
define( 'SECURE_AUTH_KEY',  'K>k ,.X6^AMo(oce?/,roz>%:ga_TY4)EsMS}v+N7.20THTV%e,-n.W$(@,MPLNR' );
define( 'LOGGED_IN_KEY',    'u->xK.4oq[YxS]qi.h=CkS+2B~oagN2Vp0t{4MDCiZ1R3W&]MDC-1ebxb8H^PmPB' );
define( 'NONCE_KEY',        't6?1*g;<n]&N44sH`K&X`]1RTzC?Ea0DcT~QR_8GzHV2S>SWfpWrZq$q=SIgLS&8' );
define( 'AUTH_SALT',        'on<*Qtz;8hvkTY.;;/N:[>hSHO/r&u8zD`MAC|n)L!,IZm:JfH01cx^9pu1hhUZ)' );
define( 'SECURE_AUTH_SALT', 'M^KE#d,[Ny(/ MGak|dnl%m7XzdlH^dY8zDN~(cLEiNXnwv(PtO.xS7^3mM j81u' );
define( 'LOGGED_IN_SALT',   'ny{;;].6ENJh#d|*zZcP6}V[;zdI7,1bG|v8n4:^ER9Y2pMl<OV1s$`0Pr=a(%+S' );
define( 'NONCE_SALT',       'J.Wp3B1,JNq/`BOPK}7>a</-`6w2 cv$)NkW9bl()MK;8OprkR/k6uBHViA.kwxi' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';

